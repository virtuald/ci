/*
 * Copyright (c) 2024 REV Robotics
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of REV Robotics nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#pragma once

#include "rev/config/BaseConfig.h"

namespace rev::spark {

class ExternalEncoderConfig : public BaseConfig {
public:
    enum Type { kQuadrature = 0 };

    static Type FromId(int id) { return kQuadrature; }

    ExternalEncoderConfig() = default;
    ~ExternalEncoderConfig() override = default;

    ExternalEncoderConfig(const ExternalEncoderConfig&) = delete;
    ExternalEncoderConfig& operator=(const ExternalEncoderConfig&) = delete;
    ExternalEncoderConfig(ExternalEncoderConfig&&) noexcept = delete;
    ExternalEncoderConfig& operator=(ExternalEncoderConfig&&) noexcept = delete;

    /**
     * Applies settings from another ExternalEncoderConfig to this one.
     *
     * <p>Settings in the provided config will overwrite existing values in this
     * object. Settings not specified in the provided config remain unchanged.
     *
     * @param config The ExternalEncoderConfig to copy settings from
     * @return The updated ExternalEncoderConfig for method chaining
     */
    ExternalEncoderConfig& Apply(ExternalEncoderConfig& config);

    /**
     * Set the counts per revolutions of the External encoder.
     *
     * @param cpr The counts per rotation
     * @return The modified ExternalEncoderConfig object for method
     * chaining
     */
    ExternalEncoderConfig& CountsPerRevolution(int cpr);

    /**
     * Set the phase of the External encoder so that it is in phase with the
     * motor itself.
     *
     * @param inverted The phase of the encoder
     * @return The modified ExternalEncoderConfig object for method
     * chaining
     */
    ExternalEncoderConfig& Inverted(bool inverted);

    /**
     * Set the conversion factor for the position of the External encoder.
     * Position is returned in native units of rotations and will be multiplied
     * by this conversion factor.
     *
     * @param factor The conversion factor to multiply the native units by
     * @return The modified ExternalEncoderConfig object for method
     * chaining
     */
    ExternalEncoderConfig& PositionConversionFactor(double factor);

    /**
     * Set the conversion factor for the velocity of the External encoder.
     * Velocity is returned in native units of rotations per minute and will be
     * multiplied by this conversion factor.
     *
     * @param factor The conversion factor to multiply the native units by
     * @return The modified ExternalEncoderConfig object for method
     * chaining
     */
    ExternalEncoderConfig& VelocityConversionFactor(double factor);

    /**
     * Set the sampling depth of the velocity calculation process of the
     * External encoder. This value sets the number of samples in the average
     * for velocity readings. For a quadrature encoder, this can be any value
     * from 1 to 64 (default).
     *
     * @param depth The velocity calculation process's sampling depth
     * @return The modified ExternalEncoderConfig object for method
     * chaining
     */
    ExternalEncoderConfig& AverageDepth(int depth);

    /**
     * Set the position measurement period used to calculate the velocity of the
     * External encoder. For a quadrature encoder, this number may be between 1
     * and 100 (default).
     *
     * <p>The basic formula to calculate velocity is change in position / change
     * in time. This parameter sets the change in time for measurement.
     *
     * @param periodMs Measurement period in milliseconds
     * @return The modified ExternalEncoderConfig object for method
     * chaining
     */
    ExternalEncoderConfig& MeasurementPeriod(int periodMs);
};

}  // namespace rev::spark
